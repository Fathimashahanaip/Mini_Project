from django.db import models
from product.models import Product
from order.models import Order
from customer.models import Customer

# Create your models here.
class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True)
    # order_id = models.IntegerField()
    order=models.ForeignKey(Order,to_field='order_id',on_delete=models.CASCADE)
    # product_id = models.IntegerField()
    product=models.ForeignKey(Product,to_field='product_id',on_delete=models.CASCADE)
    total = models.CharField(max_length=50)
    # product=models.ForeignKey(Product,to_field='total',on_delete=models.CASCADE)
    payment_date = models.DateField()
    payment_status = models.CharField(max_length=50)
    payment_mod = models.CharField(max_length=25)
    # customer_id = models.IntegerField()
    customer=models.ForeignKey(Customer,to_field='customer_id',on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'payment'


