from django.shortcuts import render
from payment.models import Payment
from product.models import Product
import datetime
# Create your views here.
def c_add_payment(request):
    obj=Payment.objects.all()
    context={
        'objval':obj
    }
    return render(request,'payment/C_Add_Payment.html',context)
def add(request,idd):
    o=Product.objects.filter(product_id=idd)
    context={
        'bb':o,
    }
    if request.method=="POST":
        ii=request.session["uid"]
        o=Payment()
        o.order_id=idd

        o.payment_date=datetime.datetime.today()
        o.payment_mod=request.POST.get('Mod')
        o.price=request.POST.get('tot')
        o.payment_status='paid'
        o.customer_id=ii
        o.save()
    return render(request,'payment/C_Payment2.html',context)
def view_payment(request):
    obj=Payment.objects.all()
    context={
        'objval':obj

    }
    return render(request,'payment/view_payment.html',context)
