from django.conf.urls import url
from payment import views

urlpatterns = [
    url('^c_add_payment/',views.c_add_payment),
    url('^c_payment2/(?P<idd>\w+)',views.add,name='c_payment2'),
    url('^view_payment/',views.view_payment)

]