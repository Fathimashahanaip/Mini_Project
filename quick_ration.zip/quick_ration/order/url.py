from django.conf.urls import url
from order import views

urlpatterns = [
    # url('^c_order_product/',views.c_orderProduct),
    # url('^c_order_product2/',views.c_order_product2),
    url('^c_order_status/',views.c_order_status),
    url('^c_view_order_updates/',views.c_view_order_updates),
    url('^update_order_status/',views.update_order_status),
    url('^manageorder/',views.manageorder),
    url('approve/(?P<idd>\w+)', views.approve, name='approve'),
    url('reject/(?P<idd>\w+)', views.reject, name='reject'),
    url('order_status/(?P<idd>\w+)', views.order_status, name='order_status'),
    url('order_status/',views.order_status),
    url('^status/',views.status),
    url('^vapstatus/',views.viewapprovedstatus),


]