from django.db import models
from customer.models import Customer
from product.models import Product

# Create your models here.
class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    # customer_id = models.IntegerField()
    customer=models.ForeignKey(Customer,to_field='customer_id',on_delete=models.CASCADE)
    # product_id = models.IntegerField()
    product=models.ForeignKey(Product,to_field='product_id',on_delete=models.CASCADE)
    order_status = models.CharField(max_length=50)
    date = models.DateField()

    class Meta:
        # managed = False
        db_table = 'order'
