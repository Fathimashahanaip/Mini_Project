from django.shortcuts import render
from order.models import Order

# Create your views here.


def c_order_status(request):
    obj=Order.objects.all()
    context={
        'objval':obj
    }
    return render(request,'order/C_order_Status.html',context)
def c_view_order_updates(request):
    obj=Order.objects.all()
    context={
        'objval':obj
    }
    return render(request,'order/C_View_Order_Updates.html',context)
def update_order_status(request):
    obj=Order.objects.all()
    context={
        'objval':obj
    }
    return render(request,'order/Update_order_status.html',context)
def manageorder(request):
    obj=Order.objects.filter(order_status="pending")
    context={
        'objval':obj
    }
    return render(request,'order/manageorder.html',context)


def approve(request,idd):
    obj=Order.objects.get(order_id=idd)
    obj.order_status="Approved"
    obj.save()
    return manageorder(request)
def reject(request,idd):
    obj=Order.objects.get(order_id=idd)
    obj.order_status="Reject"
    obj.save()
    return  manageorder(request)

def order_status(request,idd):
    objlist=Order.objects.filter(order_id=idd)
    context={
        'obval':objlist,
    }
    if request.method=="POST":
        o=Order.objects.get(order_id=idd)
        o.order_status=request.POST.get('status')
        o.save()
        return status(request)
    return render(request,'order/Order_status.html',context)
def status(request):
    obj=Order.objects.filter(order_status="Approved")
    context={
        'objval':obj
    }
    return render(request,'order/status.html',context)
def viewapprovedstatus(request):
    o=Order.objects.filter(order_status='approved')
    context={
        'opp':o,
    }
    return render(request,'order/viewapprovedstatus.html',context)