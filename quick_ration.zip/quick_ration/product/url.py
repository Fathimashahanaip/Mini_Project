from django.conf.urls import url
from product import views
urlpatterns = [
    url('^add_product_with_ration_catagory/',views.add_product_with_ration_catagory),
    url('^c_view_product/',views.c_view_product),
    url('^update_stock/',views.update_stock),
    url('update_stock2/(?P<idd>\w+)', views.update_stock2, name='update_stock2'),
    url('orderr/(?P<idd>\w+)', views.orderr, name='orderr'),

]