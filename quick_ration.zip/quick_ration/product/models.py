from django.db import models

# Create your models here.
class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=25)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    quantity = models.IntegerField()
    total = models.DecimalField(max_digits=5, decimal_places=2)
    stock = models.IntegerField()
    status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'product'




