from itertools import product

from django.shortcuts import render
from product.models import Product
from category.models import Catagory
from django.core.files.storage import FileSystemStorage
from order.models import Order
import datetime

# Create your views here.
def add_product_with_ration_catagory(request):
    # return render(request, 'product/Add_Product_with_Ration_Catagory.html')
    objlist=Catagory.objects.all()
    context={
        'obval':objlist,
    }
    if request.method=="POST":
        o=Product()
        o.product_name=request.POST.get('Product')
        o.category_id=request.POST.get('cate')
        # o.image=request.POST.get('image')
        o.price=request.POST.get('Price')
        o.quantity=request.POST.get('Quantity')
        o.stock=request.POST.get('Stock')
        o.image = '1'

        # myfile = request.FILES["image"]
        # fs = FileSystemStorage()
        # filename = fs.save(myfile.name, myfile)

        # o.image = myfile.name
        v=request.POST.get('Price')
        ii=request.POST.get('Quantity')
        o.total=int(v)*int(ii)
        o.save()
    return render(request,'product/Add_Product_with_Ration_Catagory.html',context)
from customer.models import Customer
def c_view_product(request):
    # uu=   request.session["uid"]
    ui = request.session["uid"]
    oo=Customer.objects.get(customer_id=ui)
    bb=oo.category
    obj=Product.objects.filter(category_id=bb)
    context={
        'objval':obj
    }
    return render(request,'product/C_view_Products.html',context)


def C_view_Product(request):
    obj=Product.objects.filter(status="pending")
    context={
        'objval':obj
    }
    return render(request,'product/C_view_Products.html',context)


def orderr(request,idd):
    obj=Product.objects.get(product_id=idd)
    obj.status="place order"
    obj.save()
    ob=Order()
    ob.product_id=idd
    ob.customer_id=1
    ob.date=datetime.date.today()
    ob.order_status="pending"
    ob.save()
    return C_view_Product(request)

def update_stock(request):
    obj=Product.objects.all()
    context={
        'objval':obj
    }
    return render(request,'product/Update_Stock.html',context)


def update_stock2(request,idd):
    ob=Product.objects.filter(product_id=idd)
    context={
        'obval':ob,
    }

    if request.method=="POST":
        o=Product.objects.get(product_id=idd)
        o.product_name=request.POST.get('Pname')
        o.stock=request.POST.get('Stock')
        o.save()
        return update_stock(request)
    return render(request,'product/update_stock2.html',context)