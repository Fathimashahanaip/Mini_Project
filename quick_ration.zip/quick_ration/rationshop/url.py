from django.conf.urls import url
from rationshop import views
urlpatterns = [
    url('^register/',views.register)
]