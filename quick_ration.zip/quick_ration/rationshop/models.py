from django.db import models

# Create your models here.
class Register(models.Model):
    rationshop_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=25)
    address = models.CharField(max_length=100)
    phone = models.IntegerField()
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=25)

    class Meta:
        # managed = False
        db_table = 'register'


