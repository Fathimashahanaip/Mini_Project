from django.shortcuts import render
from rationshop.models import Register
from login.models import Login

# Create your views here.
def register(request):
    if request.method=="POST":
        o=Register()
        o.name=request.POST.get('Name')
        o.address=request.POST.get('Address')
        o.phone=request.POST.get('phone')
        o.email=request.POST.get('Email')
        o.password=request.POST.get('Password')
        o.save()

        ob=Login()
        ob.username=request.POST.get('Email')
        ob.password=request.POST.get('Password')
        ob.type="rationshop"
        ob.user_id=o.rationshop_id
        ob.save()
    return render(request,'rationshop/Register.html')
