from django.shortcuts import render

# Create your views here.
def index_customer(request):
    return render(request,'temp/index_customer.html')

def index_copy(request):
    return render(request,'temp/index - Copy.html')