from django.conf.urls import url
from temp import views

urlpatterns = [
    url('^index_customer/',views.index_customer),
   url('^index_copy/',views.index_copy)

]