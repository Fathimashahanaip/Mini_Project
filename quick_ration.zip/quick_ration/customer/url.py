from django.conf.urls import url
from customer import views

urlpatterns = [
    url('^c_registration/',views.c_registration),
    url('^rationshop_registration_view/',views.rationshop_registration_view),
    url('approvecus/(?P<idd>\w+)', views.approvecus, name='approvecus'),
    url('rejectcus/(?P<idd>\w+)', views.rejectcus, name='rejectcus'),

]