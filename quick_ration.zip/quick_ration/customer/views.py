from django.shortcuts import render
from customer.models import Customer
from login.models import Login
from category.models import Catagory
# Create your views here.
def c_registration(request):
    obb=Catagory.objects.all()
    context={
        'val':obb
    }
    if request.method=="POST":
        o=Customer()
        o.rationcard_number=request.POST.get('Cardnumber')
        o.taluk=request.POST.get('Taluk')
        o.customer_name=request.POST.get('Name')
        o.address=request.POST.get('Address')
        o.punchayath=request.POST.get('Punchayath')
        o.category=request.POST.get('Catagory')
        o.ward_number=request.POST.get('Ward')
        o.members_count=request.POST.get('Members')
        o.phone=request.POST.get('Phone')
        o.email=request.POST.get('Email')
        o.password=request.POST.get('Password')
        o.registration_status = "pending"
        o.save()

        ob=Login()
        ob.username=request.POST.get('Email')
        ob.password=request.POST.get('Password')
        ob.type="pending"
        ob.user_id=o.customer_id
        ob.save()


    return render(request,'customer/C_Register.html',context)
def rationshop_registration_view(request):
    obj=Customer.objects.filter(registration_status="pending")
    context={
        'objval':obj
    }
    return render(request,'customer/rationshop_registration_view.html',context)

def approvecus(request,idd):
    obj = Customer.objects.get(customer_id=idd)
    obj.registration_status = 'approved'
    obj.save()
    o=Login.objects.get(user_id=idd)
    o.type='customer'
    o.save()

    return rationshop_registration_view(request)

def rejectcus(request,idd):
    obj = Customer.objects.get(customer_id=idd)
    obj.registration_status = 'Rejected'
    obj.save()
    return rationshop_registration_view(request)
