from django.db import models

# Create your models here.
class Customer(models.Model):
    customer_id = models.AutoField(primary_key=True)
    rationcard_number = models.CharField(max_length=20)
    taluk = models.CharField(max_length=25)
    customer_name = models.CharField(max_length=25)
    punchayath = models.CharField(max_length=25)
    address = models.CharField(max_length=100)
    category = models.CharField(max_length=25)
    ward_number = models.IntegerField()
    members_count = models.IntegerField()
    phone = models.CharField(max_length=30)
    email = models.CharField(max_length=25)
    password = models.CharField(max_length=25)
    registration_status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'customer'





