from django.shortcuts import render
from category.models import Catagory

# Create your views here.
def addcat(request):

    if request.method=="POST":
        o=Catagory()
        o.category=request.POST.get('Catagory')
        # o.details=request.POST.get('Details')
        o.save()

    return render(request,'category/Add_Ration_category.html')